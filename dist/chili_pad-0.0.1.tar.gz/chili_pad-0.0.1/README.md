# chili_pad

## Description
This is a driver class for the chili_pad modified by Sani replacing the the control board and the powersupply.

## Installation

## Usage

[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)